from odoo import fields, models, api

class ProductionLot1(models.Model):
    _inherit = ['stock.production.lot']
    _rec_name = 'name1'
    
    name1 = fields.Char(string="nom",compute='_compute_name')
    @api.depends('name','expiration_date')
    def _compute_name(self):
        for record in self:
            record.name1 = record.name + '[' + str(record.expiration_date) + ']'