{
'name': ' Gestion des demandes dachats ',
'description': '  ',
'author': 'Cisse Souleymane',
'data': [
       ],

'depends': ['stock','product_expiry'],
'application': True,

}